<?php


	
    $mysqli = new mysqli("localhost", "vrxbwjkb_shahzadbhai", "shahzadbhai", "vrxbwjkb_shahzadbhai");
	if($mysqli->connect_errno) {
		echo "Failed to connect to MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
    }

	if(!($stmt = $mysqli->prepare("SELECT * FROM feedback"))) {
		echo "Prepare failed: (" . $mysqli->errno . ") " . $mysqli->error;
	}
		
	$stmt->execute();
    $result = $stmt->get_result();

    $stmt->close();
    $mysqli->close();
?>

<!DOCTYPE html>
<html>
    <head>
        <title>Queries for Scholarship app
        </title>
        <style>
            table {
                font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
                border-collapse: collapse;
                width: 100%;
            }

            table td, table th {
                border: 1px solid #ddd;
                padding: 8px;
            }

            table tr:nth-child(even){
                background-color: #f2f2f2;
            }

            table tr:hover {
                background-color: #ddd;
            }

            table th {
                padding-top: 12px;
                padding-bottom: 12px;
                text-align: left;
                background-color: #4CAF50;
                color: white;
            }
        </style>
    </head>
    <body>
        <header>

        </header>
        <div>
            <table>
                <thead>
                    <tr>
                        <th> Name</th>
                        <th>Email</th>
                        <th> Feedback</th>
                        
                        
                    </tr>
                </thead>
                
                
                
       
                <?php
                    while($row = $result->fetch_assoc()) {
                ?>
                <tbody>
                    <tr>
                        <td><?=$row['name'];?></td>
                        <td><a href="mailto:<?=$row['email'];?>"><?=$row['email'];?></a></td>
                        <td><?=$row['feedback'];?></td>
                       
                        
                    </tr>
                </tbody>
                <?php
                    }
                ?>
            </table>
        </div>
    </body>
</html>
