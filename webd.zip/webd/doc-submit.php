<?php
    $fname = $_POST['fname'];
    
     $photo1 = '';
    
    if ($_FILES['photo1']['error'] !== 4) {
    $target_file = 'uploads/' . basename($_FILES['photo1']['name']);
    $fileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    // Check for allowed file types
    $allowedTypes = ['jpg', 'jpeg', 'png', 'pdf'];
    if (!in_array($fileType, $allowedTypes)) {
        exit('Sorry, only JPG, JPEG, PNG & PDF files are allowed.');
    }

    // If not a PDF, check if it's a valid image
    if ($fileType !== 'pdf') {
        if (getimagesize($_FILES['photo1']['tmp_name']) === false) {
            exit('File is not an image. Only images or PDFs can be uploaded.');
        }
    }

    if (!move_uploaded_file($_FILES['photo1']['tmp_name'], $target_file)) {
        exit('Sorry, there was an error uploading your file.');
    }

    $photo1 = basename($_FILES['photo1']['name']);
}



    
     $photo2 = '';
    
     if ($_FILES['photo2']['error'] !== 4) {
    $target_file = 'uploads/' . basename($_FILES['photo2']['name']);
    $fileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    // Check for allowed file types
    $allowedTypes = ['jpg', 'jpeg', 'png', 'pdf'];
    if (!in_array($fileType, $allowedTypes)) {
        exit('Sorry, only JPG, JPEG, PNG & PDF files are allowed.');
    }

    // If not a PDF, check if it's a valid image
    if ($fileType !== 'pdf') {
        if (getimagesize($_FILES['photo2']['tmp_name']) === false) {
            exit('File is not an image. Only images or PDFs can be uploaded.');
        }
    }

    if (!move_uploaded_file($_FILES['photo2']['tmp_name'], $target_file)) {
        exit('Sorry, there was an error uploading your file.');
    }

    $photo2 = basename($_FILES['photo2']['name']);
}


    
     $photo3 = '';
    
    if ($_FILES['photo3']['error'] !== 4) {
    $target_file = 'uploads/' . basename($_FILES['photo3']['name']);
    $fileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    // Check for allowed file types
    $allowedTypes = ['jpg', 'jpeg', 'png', 'pdf'];
    if (!in_array($fileType, $allowedTypes)) {
        exit('Sorry, only JPG, JPEG, PNG & PDF files are allowed.');
    }

    // If not a PDF, check if it's a valid image
    if ($fileType !== 'pdf') {
        if (getimagesize($_FILES['photo3']['tmp_name']) === false) {
            exit('File is not an image. Only images or PDFs can be uploaded.');
        }
    }

    if (!move_uploaded_file($_FILES['photo3']['tmp_name'], $target_file)) {
        exit('Sorry, there was an error uploading your file.');
    }

    $photo3 = basename($_FILES['photo3']['name']);
}
    
    
    
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    
    
    $mysqli = new mysqli('localhost', 'vrxbwjkb_shahzadbhai', 'shahzadbhai', 'vrxbwjkb_shahzadbhai');
    if ($mysqli->connect_errno)
        echo "Failed to connect to MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
        
    $stmt = $mysqli->prepare("INSERT INTO `studentdetails`(`fname`, `photo1`,`photo2`, `photo3`, `email`, `phone`) VALUES (?, ?, ?, ?, ?, ?)");
    if (false === $stmt) {
        die('prpe() failed: ' . htmlspecialchars($stmt->error));
    }
    
    $bind = $stmt->bind_param("ssssss", $fname, $photo1, $photo2, $photo3, $email, $phone);
    if (false === $bind) {
        die('bind() failed: ' . htmlspecialchars($stmt->error));
    }
    
    if (false === $stmt->execute()) {
        die('execute() failed: ' . htmlspecialchars($stmt->error));
    }
    
    $stmt->close();
    $mysqli->close();
    
    echo "<h1>Details saved successfully.</h1>
        <a style ='font-size:16px;' href = 'https://simranproject.serventys.in/'>Go back to Home Page</a>";
    
?>