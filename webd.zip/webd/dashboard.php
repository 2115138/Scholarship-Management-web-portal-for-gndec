<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    // If the user is not logged in, redirect them to the login page
    header('Location: index.html');
    exit();
}

echo "Welcome to the Dashboard, " . $_SESSION['username'] . "!";
echo "<br><a href='logout.php'>Logout</a>";
?>
