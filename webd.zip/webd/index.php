<!DOCTYPE html>

<html ng-app="myapp">
    <style>
* {
  box-sizing: border-box;
}

/* Create three equal columns that floats next to each other */
.column {
  float: left;
  width: 33.33%;
  padding: 10px;
  height: 300px; /* Should be removed. Only for demonstration */
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

/* Responsive layout - makes the three columns stack on top of each other instead of next to each other */
@media screen and (max-width: 600px) {
  .column {
    width: 100%;
  }
}
</style>
	
<head>

		<!-- Basic -->
		<meta charset="utf-8">
		<meta name="keywords" content="HTML5 Template" />
		<meta name="description" >
		<meta name="author" content="pixelgeeklab.com">

		<!-- Mobile Metas -->
		<meta name="viewport" content="width=device-width, initial-scale=1.0">

		<!-- Web Fonts  -->
		<link href='css/css.css' rel='stylesheet' type='text/css'>
		<link rel="stylesheet" href="fonts/font.css">
		
		<!-- Vendor CSS -->
		<link rel="stylesheet" href="vendor/fontawesome/css/font-awesome.css">
		<link rel="stylesheet" href="vendor/owlcarousel/owl.carousel.css" media="screen">
		<link rel="stylesheet" href="vendor/owlcarousel/owl.theme.css" media="screen">
		<link href="vendor/owl-carousel/owl.transitions.html" rel="stylesheet" media="screen">
		<link rel="stylesheet" href="vendor/flexslider/flexslider.css" media="screen">
		<link rel="stylesheet" href="vendor/chosen/chosen.css" media="screen">
		<link rel="stylesheet" href="vendor/magnific-popup/magnific-popup.css" media="screen">

		<!-- Theme CSS -->
		<link rel="stylesheet" href="css/theme.css">
		<link rel="stylesheet" href="css/theme-animate.css">

        
		<!-- Style Switcher-->

		<!-- Head libs -->
		<script src="vendor/modernizr/modernizr.js"></script>

		<!--[if IE]>
			<link rel="stylesheet" href="css/ie.css">
		<![endif]-->

		<!--[if lte IE 8]>
			<script src="vendor/respond/respond.js"></script>
			<script src="vendor/excanvas/excanvas.js"></script>
		<![endif]-->

        <style>
			.container {
				background-color: #465a63;
				position:relative;
				margin-top:100px;
			}
			.row{
			margin-left:50px;
			margin-right:50px;
			text-align:center;
			}
			.login p{
			position:relative;
			text-align:center;
			font-size:30px;
			color:#ffffff;
			}
			
			p{
			position:relative;
			text-align:center;
			font-family:'Quicksand';
			font-size:35px;
			color:#ffffff;
			font-weight:200;
			}
			h2{
			position:relative;
			text-align:center;
			font-size:30px;
			color:#ffffff;
			font-weight:200;
			}
			h3{
			text-align:center;
			font-size:80px;
			color:#ffffff;
			font-weight:200;
			}
			img{
			align:middle;
			}
			
        </style>

<!-- script back button -->
		
		<script>
		function onLoad() 
		{
			document.addEventListener("deviceready", deviceReady, false);
		}
		function deviceReady() 
		{
			document.addEventListener("backbutton", backButtonCallback, false);
		}
		function backButtonCallback() 
		{
			navigator.app.exitApp();
		}
		</script>
</head>
	
	<!-- angular js -->
	<script src="js/angular-1.3.js"></script>
	<script src="js/angular_cookies.js"></script>
<body >
		<div class="container">
		    
		<div class="row">
		    
		<h2>Scholarship App</h2>

		<div class="col-lg-4">
		
		
			<div class="login">
				<a class="btn btn-primary" href="user_login.html">
					<p>User Login</p>
				</a>
			</div>
			</div><br>
			
			
			<div class="col-lg-4">
			<div class="login">
				<a  class="btn btn-success" href="staff_login.html">
					<p>Staff Login</p>
				</a>
			</div>
			</div><br>
		
		
		<div class="col-lg-4">
			<div class="login">
				<a class="btn btn-danger"  href="admin_login.html">
					<p>Admin Login</p>
				</a>
			</div>
		</div>

		</div>
		</div>
		
		
		<?php


	
    $mysqli = new mysqli("localhost", "vrxbwjkb_shahzadbhai", "shahzadbhai", "vrxbwjkb_shahzadbhai");
	if($mysqli->connect_errno) {
		echo "Failed to connect to MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
    }

	if(!($stmt = $mysqli->prepare("SELECT * FROM schemes order by id DESC "))) {
		echo "Prepare failed: (" . $mysqli->errno . ") " . $mysqli->error;
	}
		
	$stmt->execute();
    $result = $stmt->get_result();

    $stmt->close();
    $mysqli->close();
?>
		
		 
                
		<div class="row">
		    
		  
  <div class="column" style="background-color:#aaa;">
      
	
                
    <h2>Notice</h2>
    	  <?php
                    while($row = $result->fetch_assoc()) {
                ?>
    <b><?=$row['name'];?><br></b>  
  <br>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" integrity="sha512-Evv84Mr4kqVGRNSgIGL/F/aIDqQb7xQ2vcrdIwxfjThSH8CSR7PBEakCr51Ck+w+/U6swU2Im1vVX0SVk9ABhg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <a href="https://simranproject.serventys.in/uploadspdf/<?=$row['name'];?>.pdf" download="notice.pdf"><i class="fa-solid fa-file-pdf"></i>
  Download PDF
</a>
  
   
   <?php
                    }
                ?>
  </div>
 
  
  <div class="column" style="background-color:#bbb;">
    <h2>Required Documents</h2>
    <b><?=$row['reqdoc'];?></b>
  </div>
  <div class="column" style="background-color:#ccc;">
    <h2>Address</h2>
    <b>GNDEC LUDHIANA</b>
  </div>
</div>
		


		
	

		<script src="vendor/jquery/jquery.js"></script>
		<script src="vendor/bootstrap/bootstrap.js"></script>
		<script src="vendor/jquery.validation/jquery.validation.js"></script>
		<script src="vendor/owlcarousel/owl.carousel.js"></script>
		<script src="vendor/flexslider/jquery.flexslider-min.js"></script>
		<script src="vendor/countdown/countdown.min.js"></script>
		<script src="vendor/chosen/chosen.jquery.min.js"></script>
		<script src="vendor/pricefilter/jquery.pricefilter.js"></script>
		<script src="vendor/masonry/imagesloaded.pkgd.min.js"></script>
		<script src="vendor/masonry/masonry.pkgd.min.js"></script>
		<script src="vendor/uikit/uikit.js"></script>
		<script src="vendor/magnific-popup/jquery.magnific-popup.js"></script>
		
		<!-- Theme Base, Components and Settings -->
		<script src="js/theme.html"></script>
		
		<!-- Style Switcher -->
		<script type="text/javascript" src="style-switcher/js/switcher.html"></script>
		
	<!-- angular js -->
	
</body>

<!-- Mirrored from myapphosting.in/demo/scholarship_app/web/ by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 03 Apr 2025 17:36:27 GMT -->
</html>