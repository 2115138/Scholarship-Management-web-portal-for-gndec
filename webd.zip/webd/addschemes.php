
<?php
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
    
        $name = $_POST['name'];
        $stype = $_POST['stype'];
        $sgrade = $_POST['sgrade'];
        $syear =$_POST['syear'];
        $scategory=$_POST['scategory'];
        $seligible= $_POST['seligible'];
        $reqdoc= $_POST['reqdoc'];
        $timelimit= $_POST['timelimit'];
      

      $mysqli = new mysqli('localhost', 'vrxbwjkb_shahzadbhai', 'shahzadbhai', 'vrxbwjkb_shahzadbhai');
        if ($mysqli->connect_errno)
            exit("Failed to connect to MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error);
            
        if (!($stmt = $mysqli->prepare("INSERT INTO schemes(name, stype, sgrade, syear, scategory, seligible, reqdoc,  timelimit) VALUES (?,?,?,?,?,?,?,?)")))
            exit("Prepare failed: (" . $mysqli->errno . ") " . $mysqli->error);
            
        if (!$stmt->bind_param("ssssssss", $name, $stype,  $sgrade, $syear,  $scategory,  $seligible,  $reqdoc, $timelimit))
            exit("Binding parameters failed: (" . $stmt->errno . ") " . $stmt->error);
        
        if (!$stmt->execute())
            exit("Execute failed: (" . $stmt->errno . ") " . $stmt->error);
        else
            echo "<b> Thanks</b>";
    
    
    
        $stmt->close();
        $mysqli->close();
?>

<html>
 <div class="container"  >
             <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/a/ac/Green_tick.svg/1024px-Green_tick.svg.png" width="400" height="260">

 </div> 
    
</html>