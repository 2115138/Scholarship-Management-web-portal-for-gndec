<?php
// Start the session
session_start();

// Database connection parameters
$host = 'localhost';  // or your database host
$dbname = 'vrxbwjkb_shahzadbhai';  // the database name
$username = 'shahzadbhai';  // your MySQL username
$password = 'vrxbwjkb_shahzadbhai';  // your MySQL password

// Create a connection to the database
$conn = new mysqli($host, $username, $password, $dbname);

// Check if connection is successful
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the form input
    $user = $_POST['username'];
    $pass = $_POST['password'];

    // SQL query to select the user from the database
    $sql = "SELECT * FROM users WHERE username = ?";

    // Prepare the statement
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $user);  // 's' denotes the type (string) for username
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if the user exists
    if ($result->num_rows > 0) {
        // Fetch user details
        $row = $result->fetch_assoc();
        
        // Verify the password (in real apps, use password_hash() and password_verify())
        if ($row['password'] == $pass) {
            // Set session variables and redirect
            $_SESSION['loggedin'] = true;
            $_SESSION['username'] = $user;
            header("Location: welcome.php");
            exit();
        } else {
            $error_message = "Invalid username or password.";
        }
    } else {
        $error_message = "No user found with that username.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
</head>
<body>
    <h2>Login</h2>

    <!-- Display error message if login fails -->
    <?php
    if (isset($error_message)) {
        echo "<p style='color:red;'>$error_message</p>";
    }
    ?>

    <!-- Login Form -->
    <form action="login.php" method="POST">
        <label for="username">Username:</label>
        <input type="text" id="username" name="username" required><br><br>

        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required><br><br>

        <button type="submit">Login</button>
    </form>
</body>
</html>
