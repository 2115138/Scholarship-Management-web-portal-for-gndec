<?php


	
    $mysqli = new mysqli("localhost", "vrxbwjkb_shahzadbhai", "shahzadbhai", "vrxbwjkb_shahzadbhai");
	if($mysqli->connect_errno) {
		echo "Failed to connect to MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
    }

	if(!($stmt = $mysqli->prepare("SELECT * FROM dataproject"))) {
		echo "Prepare failed: (" . $mysqli->errno . ") " . $mysqli->error;
	}
		
	$stmt->execute();
    $result = $stmt->get_result();

    $stmt->close();
    $mysqli->close();
?>

<!DOCTYPE html>
<html>
    <head>
        <title>Queries for Shahzad Bhai
        </title>
        <style>
            table {
                font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
                border-collapse: collapse;
                width: 100%;
            }

            table td, table th {
                border: 1px solid #ddd;
                padding: 8px;
            }

            table tr:nth-child(even){
                background-color: #f2f2f2;
            }

            table tr:hover {
                background-color: #ddd;
            }

            table th {
                padding-top: 12px;
                padding-bottom: 12px;
                text-align: left;
                background-color: #4CAF50;
                color: white;
            }
        </style>
    </head>
    <body>
        <header>

        </header>
        <div>
            <table>
                <thead>
                    <tr>
                       <th > Name</th>
								<th >Email</th>
								<th >Mobile</th>
								<th >College </th>
								<th >Year </th>
								<th >Class/Department </th>
								<th >Address </th>
                        
                    </tr>
                </thead>
                
                
                
       
                <?php
                    while($row = $result->fetch_assoc()) {
                ?>
                <tbody>
                    <tr>
                        <tr style="border: 1px solid black;">
								<td ng-bind="x.name"><?=$row['name'];?></td>
								<td ng-bind="x.email"><?=$row['email'];?></td>
								<td ng-bind="x.mobile"><?=$row['mobile'];?></td>
								<td ng-bind="x.field_1"><?=$row['college'];?></td>
								<td ng-bind="x.field_2"><?=$row['year'];?></td>
								<td ng-bind="x.field_3"><?=$row['dept'];?></td>
								<td ng-bind="x.field_4"><?=$row['address'];?></td>
							</tr>
                        
                        
                    </tr>
                </tbody>
                <?php
                    }
                ?>
            </table>
        </div>
    </body>
</html>
