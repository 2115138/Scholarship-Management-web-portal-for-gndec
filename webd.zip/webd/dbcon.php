<?php
    $host = 'localhost';
    $user = 'vrxbwjkb_shahzadbhai';
    $password = 'vrxbwjkb_shahzadbhai';
    $database = 'vrxbwjkb_shahzadbhai';
 
    $con = mysqli_connect($host, $user, $password, $database);
 
    if (!$con){
        ?>
            <script>alert("Connection Unsuccessful!!!");</script>
        <?php
    }
?>