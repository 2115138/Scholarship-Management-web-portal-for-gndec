<?php
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
    
        $name = $_POST['name'];
        $email = $_POST['email'];
        $password = $_POST['password'];
        $mobile =$_POST['mobile'];
        $college=$_POST['college'];
        $year= $_POST['year'];
        $dept= $_POST['dept'];
        $address= $_POST['address'];
      

      $mysqli = new mysqli('localhost', 'vrxbwjkb_shahzadbhai', 'shahzadbhai', 'vrxbwjkb_shahzadbhai');
        if ($mysqli->connect_errno)
            exit("Failed to connect to MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error);
            
        if (!($stmt = $mysqli->prepare("INSERT INTO dataproject(name, email, password, mobile, college, year, dept,  address) VALUES (?,?,?,?,?,?,?,?)")))
            exit("Prepare failed: (" . $mysqli->errno . ") " . $mysqli->error);
            
        if (!$stmt->bind_param("ssssssss", $name, $email, $password, $mobile,  $college, $year, $dept, $address))
            exit("Binding parameters failed: (" . $stmt->errno . ") " . $stmt->error);
        
        if (!$stmt->execute())
            exit("Execute failed: (" . $stmt->errno . ") " . $stmt->error);
        else
            echo "<b> Thanks</b>";
    
    
    
        $stmt->close();
        $mysqli->close();
?>

<html>
 <div class="container"  >
             <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/a/ac/Green_tick.svg/1024px-Green_tick.svg.png" width="400" height="260">

 </div> 
    
</html>
