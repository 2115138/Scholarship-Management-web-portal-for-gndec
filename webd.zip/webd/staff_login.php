<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

session_start();

// Database connection parameters
$host = 'localhost';  // or your database host
$dbname = 'vrxbwjkb_shahzadbhai';  // the database namec
$username = 'vrxbwjkb_shahzadbhai';  // your MySQL username
$password = 'shahzadbhai';  // your MySQL password

// Create a connection to the database
$conn = new mysqli($host, $username, $password, $dbname);

// Check if connection is successful
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the form input
    $user = $_POST['username'];
    $pass = $_POST['password'];

    // SQL query to select the user from the database
    $sql = "SELECT * FROM staff WHERE username = ?";

    // Prepare the statement
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $user);  // 's' denotes the type (string) for username
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if the user exists
    if ($result->num_rows > 0) {
        // Fetch user details
        $row = $result->fetch_assoc();
        
        // Verify the password (in real apps, use password_hash() and password_verify())
        if ($row['password'] == $pass) {
            // Set session variables and redirect
            $_SESSION['loggedin'] = true;
            $_SESSION['username'] = $user;
            header("Location: staff_home.php");
            exit();
        } else {
            $error_message = "Invalid username or password.";
        }
    } else {
        $error_message = "No user found with that username.";
    }
}
?>
