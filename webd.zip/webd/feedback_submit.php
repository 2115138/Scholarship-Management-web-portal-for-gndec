<?php
    $email = $_POST['email'];
    
    
    
    
    
    $name = $_POST['name'];
    $feedback = $_POST['feedback'];
    
    
    $mysqli = new mysqli('localhost', 'vrxbwjkb_shahzadbhai', 'shahzadbhai', 'vrxbwjkb_shahzadbhai');
    if ($mysqli->connect_errno)
        echo "Failed to connect to MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
        
    $stmt = $mysqli->prepare("INSERT INTO `feedback`(`email`, `name`,`feedback`) VALUES (?, ?, ?)");
    if (false === $stmt) {
        die('prpe() failed: ' . htmlspecialchars($stmt->error));
    }
    
    $bind = $stmt->bind_param("sss", $email, $name, $feedback);
    if (false === $bind) {
        die('bind() failed: ' . htmlspecialchars($stmt->error));
    }
    
    if (false === $stmt->execute()) {
        die('execute() failed: ' . htmlspecialchars($stmt->error));
    }
    
    $stmt->close();
    $mysqli->close();
    
    echo "<h1>Details saved successfully.</h1>
        <a style ='font-size:16px;' href = 'https://simranproject.serventys.in/'>Go back to Home Page</a>";
    
?>