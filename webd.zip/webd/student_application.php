 
 
 
 		<?php


	
    $mysqli = new mysqli("localhost", "vrxbwjkb_shahzadbhai", "shahzadbhai", "vrxbwjkb_shahzadbhai");
	if($mysqli->connect_errno) {
		echo "Failed to connect to MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
    }

	if(!($stmt = $mysqli->prepare("SELECT * FROM schemes order by id DESC LIMIT 1"))) {
		echo "Prepare failed: (" . $mysqli->errno . ") " . $mysqli->error;
	}
		
	$stmt->execute();
    $result = $stmt->get_result();

    $stmt->close();
    $mysqli->close();
?>


<?php
                    while($row = $result->fetch_assoc()) {
                ?>
                
                
                <H3>form id -<?=$row['id'];?> </H3>
                <H3>Scheme name -<?=$row['name'];?> </H3>
                
                 <?php
                    }
                ?>


 <form action="doc-submit.php" enctype="multipart/form-data" method="POST">
        <div id="wizard">
            
          
            <!-- SECTION 1 -->
            
                <div class="form-row"> <label>Name</label><input type="text" class="form-control" name="fname" placeholder="Name"> </div><br>
                
                 
                
                <div class="form-row"  >
                    <label>Photo ID (photo/pdf)</label>
       <input  type="file" id="photo1" name="photo1">
       
       <label>Photo ID (photo/pdf)</label>
       <input  type="file" id="photo2" name="photo2">
       
       <label>Photo ID (photo/pdf)</label>
       <input  type="file" id="photo3" name="photo3">

       
        </div><br><br>
        
    
               
                
                
                <div class="form-row"> <label>Email</label><input type="text" class="form-control" name="email" placeholder="Email (This will not be displayed anywhere)"> </div><br>
                <div class="form-row"> <label>Phone</label><input type="text" class="form-control" name="phone" placeholder="Phone number (This will not be displayed anywhere)"> </div><br>
                 
          
                
                <br>
 
               
                
          
            
            
            
            
           
           
        </div><br>
        
        <input type="submit" class="btn btn-danger" name="submit" value="Submit">
    </form>