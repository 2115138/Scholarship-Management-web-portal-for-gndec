<?php


	
    $mysqli = new mysqli("localhost", "vrxbwjkb_shahzadbhai", "shahzadbhai", "vrxbwjkb_shahzadbhai");
	if($mysqli->connect_errno) {
		echo "Failed to connect to MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
    }

	$stmt = $mysqli->prepare("SELECT * FROM studentdetails WHERE id = ?");
    $stmt->bind_param("i", intval($_GET['id']));
  
		
	$stmt->execute();
    $result = $stmt->get_result();

    $stmt->close();
    $mysqli->close();
?>

<!DOCTYPE html>
<html>
    <head>
        <title>Queries for Shahzad Bhai
        </title>
        <style>
            table {
                font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
                border-collapse: collapse;
                width: 100%;
            }

            table td, table th {
                border: 1px solid #ddd;
                padding: 8px;
            }

            table tr:nth-child(even){
                background-color: #f2f2f2;
            }

            table tr:hover {
                background-color: #ddd;
            }

            table th {
                padding-top: 12px;
                padding-bottom: 12px;
                text-align: left;
                background-color: #4CAF50;
                color: white;
            }
        </style>
    </head>
    <body>
        <header>

        </header>
        <div>
            
                
                
                
       
                <?php
                    while($row = $result->fetch_assoc()) {
                ?>
              
                        <p>Full name- <?=$row['fname'];?></p> <br>
                        <p>Email- <a href="mailto:<?=$row['email'];?>"><?=$row['email'];?></a></p>
                        <p>Phone - <?=$row['phone'];?></p><br>
                        
                        <b>photo id 1</b>
                        <img src="https://simranproject.serventys.in/uploads/<?php echo $row['photo1'];?>"><br>
                        
                        <b>photo id 2</b>
                        <img src="https://simranproject.serventys.in/uploads/<?php echo $row['photo2'];?>"><br>
                        <b>photo id 3</b>
                        <img src="https://simranproject.serventys.in/uploads/<?php echo $row['photo3'];?>"><br>
                    
                        
                        
                    
                <?php
                    }
                ?>
            
        </div>
    </body>
</html>
